#!/usr/bin/env node

"use strict";

process.env.NTL_RERUN = true;
require("./cli.js");
