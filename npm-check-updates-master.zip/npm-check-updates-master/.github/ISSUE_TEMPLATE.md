- [ ] I have searched for [similar issues](https://github.com/raineorshine/npm-check-updates/issues)
- [ ] I am using the latest version of `npm-check-updates`
- [ ] I am using `node >= 10.17`

---------------------------

## Steps to Reproduce

## Current Behavior

## Expected Behavior
