### go-simplejson

a Go package to interact with arbitrary JSON

[![Build Status](https://secure.travis-ci.org/bitly/go-simplejson.png?branch=master)](http://travis-ci.org/bitly/go-simplejson) [![GoDoc](https://godoc.org/github.com/bitly/go-simplejson?status.svg)](https://godoc.org/github.com/bitly/go-simplejson) [![GitHub release](https://img.shields.io/github/release/bitly/go-simplejson.svg)](https://github.com/bitly/go-simplejson/releases/latest)


### Importing

    import github.com/bitly/go-simplejson

### Documentation

Visit the docs on [Go package discovery & docs](https://pkg.go.dev/github.com/bitly/go-simplejson)
