module.exports = () => ({
  scripts: {
    functionConfig: 'echo worked!',
  },
})
