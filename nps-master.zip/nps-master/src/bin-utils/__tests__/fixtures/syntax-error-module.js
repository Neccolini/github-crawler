module.exports = {
  foo: 'Hello'
  bar: 'No comma!'
}
