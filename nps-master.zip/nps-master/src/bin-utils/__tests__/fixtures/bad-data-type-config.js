module.exports = 'cannot be a string'
