module.exports = {
  foo: 'Hello',
  bar: 'No comma!'
};

throw new Error('oops, I did it again')
