module.exports = function () {
  return {}
}
