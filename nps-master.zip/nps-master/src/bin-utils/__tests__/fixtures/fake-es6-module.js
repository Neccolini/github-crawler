module.exports = {
  __esModule: true,
  default: {
    scripts: {
      skywalker: `echo "That's impossible!!"`,
    },
    options: {},
  },
}
