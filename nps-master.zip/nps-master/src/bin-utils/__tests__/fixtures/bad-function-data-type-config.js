module.exports = () => ['cannot be a function that returns an array']
