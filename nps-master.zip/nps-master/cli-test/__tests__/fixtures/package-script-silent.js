module.exports = {
    scripts: {
      default: 'echo "silent"',
    },
    options: {
        silent: true,
    }
}
