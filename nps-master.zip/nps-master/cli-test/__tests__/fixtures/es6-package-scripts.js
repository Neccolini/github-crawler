export default {
  scripts: {
    log: 'echo "log"',
  },
}
