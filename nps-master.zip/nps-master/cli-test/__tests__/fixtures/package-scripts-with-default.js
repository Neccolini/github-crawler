module.exports = {
  scripts: {
    default: 'echo "default script"',
  },
}
