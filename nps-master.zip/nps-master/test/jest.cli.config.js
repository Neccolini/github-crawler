module.exports = {
  rootDir: '../cli-test',
  testEnvironment: 'node',
  testPathIgnorePatterns: ['/node_modules/', '/fixtures/', '/helpers/'],
}
